# gr-rfnoc_example
Integrating UHD and fpga files into one directory

Based on copy block - Bypassing input into output
