source FPGA_TOP_DIR/usrp3/top/e300/setupenv.sh
