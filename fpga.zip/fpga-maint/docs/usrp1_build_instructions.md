# Generation 1 USRP Build Documentation

The USRP FPGA build system requires only the Altera FPGA tools

- Download [Altera Quartus](https://www.altera.com/download/sw/dnl-sw-index.jsp)
- The top-level project is located in `usrp1/toplevel/usrp_std/`
- Use the Quartus GUI environment to build the project
