The following files were generated for 'hbdec1' in directory
/disk2/ianb/ettus/fpgadev2/fpgadev/usrp3/top/b200/coregen_dsp/

Model Parameter Resolution:
   Resolves generated model parameter values on the component instance.

   * hbdec1.mif
   * hbdec1_reload_order.txt

ISE file generator:
   Add description here...

   * hbdec1_flist.txt

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * hbdec1.mif
   * hbdec1_reload_order.txt

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * hbdec1.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * hbdec1.ngc
   * hbdec1.v
   * hbdec1.veo
   * hbdec1COEFF_auto0_0.mif
   * hbdec1COEFF_auto0_1.mif
   * hbdec1COEFF_auto0_2.mif
   * hbdec1COEFF_auto0_3.mif
   * hbdec1COEFF_auto0_4.mif
   * hbdec1COEFF_auto0_5.mif
   * hbdec1COEFF_auto_HALFBAND_CENTRE0.mif
   * hbdec1_reload_addrfilt_decode_rom.mif
   * hbdec1filt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * hbdec1.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * hbdec1.asy
   * hbdec1.mif
   * hbdec1_reload_order.txt

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * hbdec1_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * hbdec1.gise
   * hbdec1.xise

Deliver Readme:
   Readme file for the IP.

   * hbdec1_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * hbdec1_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

