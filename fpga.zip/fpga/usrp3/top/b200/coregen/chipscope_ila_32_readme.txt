The following files were generated for 'chipscope_ila_32' in directory
/home/ianb/fpgapriv_usrp3/fpgapriv/usrp3/top/b200/coregen/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_ila_32.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_ila_32.cdc
   * chipscope_ila_32.constraints/chipscope_ila_32.ucf
   * chipscope_ila_32.constraints/chipscope_ila_32.xdc
   * chipscope_ila_32.ncf
   * chipscope_ila_32.ngc
   * chipscope_ila_32.ucf
   * chipscope_ila_32.v
   * chipscope_ila_32.veo
   * chipscope_ila_32.xdc
   * chipscope_ila_32_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_ila_32.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * chipscope_ila_32.gise
   * chipscope_ila_32.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_ila_32_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_ila_32_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

