The following files were generated for 'fifo_xlnx_512x36_2clk_18to36' in directory 
/home/ianb/ettus/sram_fifo/fpgapriv/usrp2/coregen/

fifo_generator_ug175.pdf:
   Please see the core data sheet.

fifo_xlnx_512x36_2clk_18to36.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

fifo_xlnx_512x36_2clk_18to36.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

fifo_xlnx_512x36_2clk_18to36.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

fifo_xlnx_512x36_2clk_18to36.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

fifo_xlnx_512x36_2clk_18to36.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

fifo_xlnx_512x36_2clk_18to36.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

fifo_xlnx_512x36_2clk_18to36_readme.txt:
   Text file indicating the files generated and how they are used.

fifo_xlnx_512x36_2clk_18to36_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

fifo_xlnx_512x36_2clk_18to36_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

