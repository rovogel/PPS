gnuradio.uhd
============

.. autoclass:: gnuradio.uhd.usrp_block
