gnuradio.vocoder
================

.. automodule:: gnuradio.vocoder

.. autoblock:: gnuradio.vocoder.alaw_decode_bs
.. autoblock:: gnuradio.vocoder.alaw_encode_sb
.. autoblock:: gnuradio.vocoder.codec2_decode_ps
.. autoblock:: gnuradio.vocoder.codec2_encode_sp
.. autoblock:: gnuradio.vocoder.cvsd_decode_bs
.. autoblock:: gnuradio.vocoder.cvsd_encode_sb
.. autoblock:: gnuradio.vocoder.g721_decode_bs
.. autoblock:: gnuradio.vocoder.g721_encode_sb
.. autoblock:: gnuradio.vocoder.g723_24_decode_bs
.. autoblock:: gnuradio.vocoder.g723_24_encode_sb
.. autoblock:: gnuradio.vocoder.g723_40_decode_bs
.. autoblock:: gnuradio.vocoder.g723_40_encode_sb
.. autoblock:: gnuradio.vocoder.gsm_fr_decode_ps
.. autoblock:: gnuradio.vocoder.gsm_fr_encode_sp
.. autoblock:: gnuradio.vocoder.ulaw_decode_bs
.. autoblock:: gnuradio.vocoder.ulaw_encode_sb
