gnuradio.wxgui
==============

.. autoclass:: gnuradio.wxgui.oscope_sink_x
.. autoclass:: gnuradio.wxgui.histo_sink_f
